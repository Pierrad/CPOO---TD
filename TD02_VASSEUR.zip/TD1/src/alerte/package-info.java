/**
 * All the classes that handle Alert
 */
package alerte;