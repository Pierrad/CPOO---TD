package alerte;

public interface INotification {
    String getMessage();

    void setMessage(String message);

    Integer getId();

    void setId(Integer id);
}
