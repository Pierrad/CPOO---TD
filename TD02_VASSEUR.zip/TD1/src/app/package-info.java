/**
 * The main classes of the app (the app and the main controller)
 */
package app;