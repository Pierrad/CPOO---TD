/**
 * All the devices classes and the classes to handle them
 */
package dispositif;