package dispositif;

/**
 * @author Vasseur Pierre-Adrien
 * <p>
 * Enum for all type of dispositif
 */
public enum TypeOfDispositif {
    ALARME, CAMERA, CAPTEUR, DETECTEUR_MOUVEMENT, SIRENE
}
