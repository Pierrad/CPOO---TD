/**
 * The UI interface
 */
package console;