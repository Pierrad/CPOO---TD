package gestionnaire;

public interface IGestionnaire {

}
